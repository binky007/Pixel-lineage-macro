"""Local OCR-driven lobby setup and repeat-act controller."""
import re
import time

from screens import crop

DIFFICULTIES = ("Normal", "Hard", "Nightmare", "Torment")
MODIFIERS = ("No Modifier", "Elite Patrols", "Volatile Enemies", "Exhausting Battles", "Boss Rush")


def normalize(text):
    return re.sub(r"[^A-Z0-9]+", " ", text.upper()).strip()


def parse_act(text):
    match = re.search(r"\bACT\s*([0-9OI L|]{1,3})\s*/\s*10\b", text.upper())
    if not match:
        return None
    value = match[1].translate(str.maketrans({"O": "0", "I": "1", "L": "1", "|": "1"})).replace(" ", "")
    return int(value) if value.isdigit() and 1 <= int(value) <= 10 else None


class Adventure:
    def __init__(self, runner):
        self.r = runner
        self.next_scan = 0
        self.running = False
        self.returning = False
        self.candidate = None
        self.hits = 0
        self.world_index = None
        self.world_text = None
        self.pending_world = None
        self.nightmare = False
        self.actions = 0
        self.resume_difficulty = None

    def reset_lobby(self):
        self.world_index = self.world_text = self.pending_world = None
        self.nightmare = False
        self.actions = 0

    def click(self, rect, x, y):
        if self.r.aborted():
            return
        self.r._focus()
        self.r._click(rect, x, y)
        self.next_scan = time.perf_counter() + 0.8

    def step(self, rect, frame):
        r = self.r
        if not r.cfg.get("adventure_mode") and self.resume_difficulty is None:
            return False
        if time.perf_counter() < self.next_scan:
            return not self.running or self.returning or (self.candidate is not None and self.candidate != int(r.cfg.get("world_index", 1)))
        self.next_scan = time.perf_counter() + 0.8
        target = max(1, min(10, int(r.cfg.get("world_index", 1))))
        header, _, _ = crop(frame, r.cfg.get("act_area") or {"x": 0, "y": 0.055, "w": 0.065, "h": 0.04})
        act = parse_act(r.reader.text(header))
        self.hits = self.hits + 1 if act is not None and act == self.candidate else 1
        self.candidate = act
        if act is not None and not self.returning:
            if act == target:
                self.running = True
                return False
            if r.cfg.get("next_map") and self.running:
                return False  # The enabled NEXT toggle deliberately advances beyond the selected act.
            if self.hits < 2:
                return True  # do not pick another path while validating a transition
            self.returning = True
            r.status(f"Act {act} detected; returning home to repeat act {target}.")
        elif self.running and not self.returning:
            return False

        # Read visible labels; never issue an unverified sequence of menu clicks.
        lines = r.reader.read(frame)
        def find(label):
            return next((ln for ln in lines if label in normalize(ln.text)), None)
        def press(label):
            ln = find(label)
            if ln:
                self.click(rect, ln.cx, ln.cy)
                return True
            return False

        if self.returning:
            if find("SET OUT") and not find("RETURN HOME"):
                self.returning = self.running = False
                self.reset_lobby()
            else:
                # Confirmation dialogs take priority over the underlying home button.
                for label in ("YES", "CONFIRM"):
                    if press(label):
                        return True
                home = find("RETURN HOME")
                if home:
                    # Short bursts handle clicks the game drops during transitions.
                    # Re-scan after every burst so we stop when the castle appears.
                    for attempt in range(3):
                        if r.aborted():
                            return True
                        self.click(rect, home.cx, home.cy)
                        if attempt < 2:
                            time.sleep(0.12)
                    self.next_scan = time.perf_counter() + 0.2
                    return True
                r.status("Waiting for Return Home or its confirmation. Stop with F1 if the dialog is unfamiliar.")
                return True

        if find("START RUN"):
            self.actions += 1
            if self.actions > 45:
                r.status("Lobby setup could not be verified. Stop with F1, check unlocked acts, then restart.")
                return True
            difficulty = self.resume_difficulty or r.cfg.get("difficulty", "Nightmare")
            modifier_name = r.cfg.get("modifier", "Elite Patrols")
            r.status(f"Setting up act {target}: {difficulty} / {modifier_name}.")
            if not self.nightmare:
                index = DIFFICULTIES.index(difficulty) if difficulty in DIFFICULTIES else 2
                cx = .387 + .04 * index
                img, _, _ = crop(frame, {"x": cx-.019, "y": .40, "w": .038, "h": .04})
                if normalize(difficulty).replace(" ", "") in normalize(r.reader.text(img)).replace(" ", ""):
                    self.click(rect, round(rect.w * cx), round(rect.h * .42))
                    self.nightmare = True
                return True
            # The modifier strip has fixed geometry relative to the game viewport.
            modifier, _, _ = crop(frame, {"x": .39, "y": .451, "w": .115, "h": .04})
            if normalize(modifier_name).replace(" ", "") not in normalize(r.reader.text(modifier)).replace(" ", ""):
                if find("MODIFIER"):
                    self.click(rect, round(rect.w * 0.516), round(rect.h * 0.472))
                return True
            start = find("START AT")
            if not start:
                return True
            # Read only the selected world's label, excluding arrows and Start Run.
            img, _, _ = crop(frame, {"x": .42, "y": .708, "w": .12, "h": .024})
            name = normalize(r.reader.text(img))
            if not name:
                return True
            known_world = next((index for label, index in (("SUNMEADOW WILDS", 1), ("MOONSTONE RISE", 4), ("THE HEART OF BLIGHT", 10)) if label in name), None)
            if known_world is not None:
                self.world_index = known_world
                self.pending_world = None
            elif self.pending_world is not None:
                if name == self.world_text:
                    r.status("Waiting for the world selector to change; stop/restart if the act is locked.")
                    return True
                self.world_index = self.pending_world
                self.pending_world = None
            if self.world_index is None:
                self.click(rect, round(rect.w * .553), round(rect.h * .715))
                return True
            if self.world_index < target:
                self.world_text = name
                self.pending_world = self.world_index + 1
                self.click(rect, round(rect.w * .553), round(rect.h * .715))
                return True
            if self.world_index != target:
                self.click(rect, round(rect.w * .553), round(rect.h * .715))
                return True
            if press("START RUN"):
                self.running = True
                self.resume_difficulty = None
                self.candidate = None
                self.hits = 0
            return True
        if press("HOST A LOBBY") or press("FIND A PARTY"):
            return True
        if find("SET OUT"):
            # Castle doorway at the cursor in the reference screenshot.
            self.click(rect, round(rect.w * .4984), round(rect.h * .5))
            return True
        r.status("Adventure mode: waiting for the castle, travel menu, or hosted lobby.")
        return True
