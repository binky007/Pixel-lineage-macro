"""Recognize a visible gold Continue button before ordinary game actions."""
import time

from adventure import normalize
from screens import DEFAULT_AREAS, crop, find_button


class PopupScanner:
    def __init__(self, runner):
        self.r = runner
        self.next_scan = 0.0
        self.settle_until = 0.0
        self.battle_since = None
        self.battle_position = None

    def step(self, rect, frame):
        now = time.perf_counter()
        if now < self.settle_until:
            return True
        if now < self.next_scan:
            return False
        self.next_scan = now + 0.6
        img, x, y = crop(frame, self.r.cfg.get("continue_area") or DEFAULT_AREAS["continue_area"])
        button = find_button(img, rect.w, rect.h)
        if button is None or not button.active:
            self.battle_since = self.battle_position = None
            return False
        box = button.box
        label = img[box.y:box.y + box.h, box.x:box.x + box.w]
        kind = normalize(self.r.reader.text(label)).replace(" ", "")
        if kind == "TOBATTLE":
            position = (x + box.cx, y + box.cy)
            if self.battle_position is None or max(abs(a-b) for a,b in zip(position,self.battle_position)) > 12:
                self.battle_since = now
                self.battle_position = position
            if now - self.battle_since < 5.0:
                return False
        elif kind != "CONTINUE":
            self.battle_since = self.battle_position = None
            return False
        else:
            self.battle_since = self.battle_position = None
        if self.r.aborted():
            return True
        self.r.status("Stuck event: clicking To Battle after 5 seconds." if kind == "TOBATTLE" else "Reward popup: clicking Continue.")
        self.r._focus()
        self.r._click(rect, x + box.cx, y + box.cy)
        self.settle_until = time.perf_counter() + 0.8
        self.battle_since = self.battle_position = None
        return True
