"""Procedural starfield shared by the app's backgrounds."""
import math
import random
import time
import tkinter as tk


class CyberBackdrop(tk.Canvas):
    motion_enabled = True
    def __init__(self, parent, header=False):
        super().__init__(parent, bg="#080d19", highlightthickness=0, height=100 if header else 1)
        self.header = header
        self.animated = True
        self.phase = 0
        rng = random.Random(72)
        self.stars = [(rng.random(), rng.random(), rng.uniform(.4, 1.7), rng.random()*6.28) for _ in range(180)]
        self.timer = self.after(50, self.tick)
        self.bind("<Configure>", lambda _: self.draw(), add="+")
        self.bind("<Destroy>", self.cleanup, add="+")

    def cleanup(self, event):
        if event.widget is self and self.timer:
            self.after_cancel(self.timer)
            self.timer = None

    def tick(self):
        if self.winfo_viewable() and self.animated and self.motion_enabled:
            self.phase = time.monotonic()
            self.draw()
        self.timer = self.after(50, self.tick)

    def draw(self):
        self.delete("ambient")
        w, h = self.winfo_width(), self.winfo_height()
        root = self.winfo_toplevel()
        sw, sh = max(1, root.winfo_width()), max(1, root.winfo_height())
        ox = self.winfo_rootx()-root.winfo_rootx()
        oy = self.winfo_rooty()-root.winfo_rooty()
        t = self.phase
        for u,v,size,phase in self.stars:
            x = (u*sw-t*(1+size)*1.4)%sw-ox
            y = (v*sh+t*(1+size)*.8)%sh-oy
            if -4<x<w+4 and -4<y<h+4:
                brightness = int(65+35*(1+math.sin(t*.8+phase))/2)
                color = f"#{brightness:02x}{brightness+18:02x}{brightness+40:02x}"
                self.create_oval(x,y,x+size,y+size,fill=color,outline="",tags="ambient")
        # A fresh meteor every 2.4 seconds, with a fading 90-pixel trail.
        cycle = int(t/2.4)
        progress = (t%2.4)/1.8
        if progress<1:
            x = ((cycle*137)%max(1,sw)) + 180-progress*400-ox
            y = ((cycle*83)%max(1,int(sh*.65)))+progress*260-oy
            for j in range(12,0,-1):
                shade = 30+int((12-j)*7*(1-progress*.65))
                color=f"#{shade:02x}{shade+18:02x}{shade+35:02x}"
                self.create_line(x+j*7,y-j*4.5,x+(j-1)*7,y-(j-1)*4.5,fill=color,width=1,tags="ambient")
        if self.header:
            self.create_text(22,22,anchor="w",text="P I X E L   /   L I N E A G E",fill="#64dce9",font=("Consolas",10,"bold"),tags="ambient")
            self.create_text(20,53,anchor="w",text="STARFALL  /  CONTROL",fill="#edf5ff",font=("Segoe UI",22,"bold"),tags="ambient")
            self.create_text(22,83,anchor="w",text="YOUR JOURNEY.  ON REPEAT.",fill="#8b9cb9",font=("Consolas",9),tags="ambient")
        self.tag_lower("ambient")


class SkyFrame(tk.Frame):
    """Starfield across empty panel space; controls stay opaque and readable."""
    def __init__(self, parent, padding=0, **kwargs):
        super().__init__(parent,bg="#080d19",**kwargs)
        self.sky = CyberBackdrop(self)
        self.sky.place(x=0,y=0,relwidth=1,relheight=1)
        # A placed background must not change the frame's requested geometry.


WORLD_NAMES = {'1': 'Sunmeadow', '2': 'Dungeon', '3': 'Cursed Forest', '4': 'Moonstone Rise', '5': 'Underworld', '6': 'Withered Meadow', '7': 'Drowned Cathedral', '8': 'Glass Wastes', '9': 'Hollow Sky', '10': 'Heart of Blight'}


class WorldPicker(CyberBackdrop):
    def __init__(self,parent,variable,names,on_select):
        super().__init__(parent)
        self.configure(height=290, cursor="hand2", takefocus=True)
        self.variable,self.names,self.on_select=variable,names,on_select
        self.bind("<Configure>",lambda _: self.draw_cards(),add="+")
        self.bind("<Button-1>",self.choose)
        self.bind("<Left>",lambda _:self.select(max(1,int(variable.get())-1)))
        self.bind("<Right>",lambda _:self.select(min(10,int(variable.get())+1)))
        self.trace=variable.trace_add("write",lambda *_:self.draw_cards())
        self.bind("<Destroy>",self.remove_trace,add="+")

    def remove_trace(self,event):
        if event.widget is self:
            self.variable.trace_remove("write",self.trace)

    def draw_cards(self):
        self.delete("world")
        width=max(200,self.winfo_width())
        for i in range(1,11):
            row,col=divmod(i-1,2)
            x=col*width/2+6; y=row*57+5
            selected=int(self.variable.get())==i
            self.create_rectangle(x,y,x+width/2-12,y+49,fill="#132a40" if selected else "#0b1424",outline="#64dce9" if selected else "#263249",width=2 if selected else 1,tags="world")
            self.create_text(x+14,y+24,anchor="w",text=f"{i:02}",fill="#64dce9" if selected else "#7687a5",font=("Consolas",12,"bold"),tags="world")
            self.create_text(x+49,y+24,anchor="w",text=self.names.get(str(i),f"World {i} - add name"),width=width/2-73,fill="#edf5ff" if selected else "#b7c4da",font=("Segoe UI",10),tags="world")

    def choose(self,event):
        self.focus_set()
        col=min(1,int(event.x/(max(200,self.winfo_width())/2)))
        row=int(event.y/57)
        if 0<=row<5:self.select(row*2+col+1)

    def select(self,index):
        if self.on_select(index) is not False:
            self.variable.set(str(index))
