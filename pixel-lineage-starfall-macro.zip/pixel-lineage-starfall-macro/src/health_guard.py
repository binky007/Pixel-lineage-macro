"""Read the player's selected HP area and leave/rejoin on confirmed low health."""
import re
import time

from adventure import normalize
from input_actions import release_inputs
from screens import DEFAULT_AREAS, crop

_HP = re.compile(r'(?<![\w.])([0-9][0-9,.]*\s*[KMB]?)\s*/\s*([0-9][0-9,.]*\s*[KMB]?)(?![\w/])', re.I)


def parse_hp(text):
    """Accept one unambiguous current/max HP pair; EN is never health."""
    values = set()
    for line in str(text).splitlines():
        if re.search(r'\bEN\b', line, re.I):
            continue
        for match in _HP.finditer(line):
            pair = []
            for raw in match.groups():
                raw = raw.replace(' ', '').replace(',', '').upper()
                scale = {'K': 1000, 'M': 1000000, 'B': 1000000000}.get(raw[-1], 1)
                try:
                    pair.append(float(raw[:-1] if scale != 1 else raw) * scale)
                except ValueError:
                    break
            if len(pair) == 2 and pair[1] > 0 and 0 <= pair[0] <= pair[1]:
                values.add(tuple(pair))
    return next(iter(values)) if len(values) == 1 else None


class HealthGuard:
    def __init__(self, runner):
        self.r = runner
        self.next_scan = 0.0
        self.last_battle = None
        self.outside_since = None
        self.last_party = 0.0
        self.low_reads = 0
        self.misses = 0
        self.armed = True
        self.state = ''
        self.last_menu = 0.0
        self.menu_tries = 0

    def _rejoin(self):
        if self.r.aborted():
            return
        self.state = 'rejoining'
        self.r.recovery.request_rejoin(time.perf_counter())

    def missing(self):
        if self.state in ('menu', 'confirm'):
            self._rejoin()

    def _leave_menu(self, rect, frame, now):
        if now < self.next_scan:
            return True
        self.next_scan = now + 0.3
        lines = self.r.reader.read(frame)
        text = ' '.join(normalize(line.text) for line in lines)
        confirmation = ('ARE YOU SURE' in text or 'WANT TO LEAVE' in text) and 'LEAVE' in text
        menu = 'LEAVE' in text and any(word in text for word in ('PEOPLE', 'SETTINGS', 'RESUME'))
        leave = next((line for line in lines if re.fullmatch(r'(?:L )?LEAVE(?: EXPERIENCE| GAME)?', normalize(line.text))
                      and rect.w * .1 < line.cx < rect.w * .9 and rect.h * .15 < line.cy < rect.h * .95), None)
        if leave is not None and (confirmation or menu):
            self.r._focus()
            self.r._click(rect, leave.cx, leave.cy)
            self.last_menu = now
            if confirmation:
                if not self.r._sleep(0.6):
                    self._rejoin()
            else:
                self.state = 'confirm'
                self.next_scan = now + 0.4
            return True
        # Never click a game-world LEAVE RAID or an unrelated confirmation.
        if now - self.last_menu >= 4.0 and self.menu_tries < 3:
            self.menu_tries += 1
            self.r._focus()
            self.r._tap(False, 'esc')
            self.last_menu = now
        self.r.status('Low HP: waiting for Roblox Leave confirmation. Combat paused; F1 cancels.')
        return True

    def step(self, rect, frame, battle=False, sample=True):
        if self.r.aborted():
            return bool(self.state)
        if not self.r.cfg.get('hp_rejoin_on', False):
            self.state = ''
            self.low_reads = 0
            return False
        now = time.perf_counter()
        if self.state in ('menu', 'confirm'):
            return self._leave_menu(rect, frame, now)
        if self.state == 'rejoining':
            if self.r.recovery.active:
                return False  # Recovery owns character selection and loading.
            self.state = ''
            self.last_battle = None
        if not battle or self.r.recovery.active:
            self.low_reads = 0
            if not battle and self.outside_since is None:
                self.outside_since = now
            return False
        new_battle = self.last_battle is None or (self.outside_since is not None and now-self.outside_since >= .4)
        self.outside_since = None
        self.last_battle = now
        if new_battle:
            self.r._focus()
            self.r._click_point(rect, 'party_btn')
            self.last_party = now
            self.next_scan = now + 0.25
            self.low_reads = 0
            return True
        if not sample or now < self.next_scan:
            return False
        self.next_scan = now + 0.4
        area, _, _ = crop(frame, self.r.cfg.get('hp_area') or DEFAULT_AREAS['hp_area'])
        lines = self.r.reader.read(area)
        hp = parse_hp('\n'.join(line.text for line in lines))
        if hp is None:
            self.low_reads = 0
            self.misses += 1
            if self.misses >= 2 and now-self.last_party >= 3:
                self.r._focus()
                self.r._click_point(rect, 'party_btn')
                self.last_party = now
            self.r.note('hp', 'HP unreadable: select and test Your HP numbers.')
            return False
        self.misses = 0
        ratio = hp[0] / hp[1]
        self.r.note('hp', 'Your HP: %.1f%%' % (ratio * 100))
        threshold = max(1, min(99, int(self.r.cfg.get('hp_threshold', 50)))) / 100
        if ratio >= min(.99, threshold + .1):
            self.armed = True
        self.low_reads = self.low_reads + 1 if ratio < threshold else 0
        if not self.armed or self.low_reads < 2:
            return False
        self.armed = False  # Rearm only after HP recovers; no repeated rejoin storm.
        self.r.status('HP %.1f%% is below %.0f%%. Leaving Roblox; selecting your character, then stopping at UNFINISHED BATTLE.' % (100*ratio,100*threshold))
        release_inputs()
        self.r._new_fight()
        self.r._mode = 'hit'
        self.r._en_read = False
        self.r._skill_off = False
        self.r._skill_block = self.r._menu_at = self.r._mg_block = 0.0
        self.r.adventure.running = self.r.adventure.returning = False
        self.r.adventure.reset_lobby()
        self.r.adventure.resume_difficulty = None
        self.r.adventure.candidate = None
        self.r.adventure.hits = 0
        self.state = 'menu'
        self.menu_tries = 1
        self.last_menu = now
        self.next_scan = now + 0.3
        self.r._focus()
        self.r._tap(False, 'esc')
        return True
