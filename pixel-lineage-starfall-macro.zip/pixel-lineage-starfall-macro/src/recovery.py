"""Local OCR recovery through Roblox's registered game launch protocol."""
import os
import re
import time

from adventure import normalize
from screens import DEFAULT_AREAS, crop, find_buttons
from ocr import Line

GAME_URI = "roblox://placeId=126256942507957"
CHARACTER_RETRY_SEC = 0.5
CHARACTER_RETRY_WINDOW = 10.0
CHARACTER_RETRY_LIMIT = 20


def disconnected(text):
    text = normalize(text)
    context = any(word in text for word in (
        "DISCONNECTED", "CONNECTION", "NETWORK", "INTERNET", "ROBLOX HAS CRASHED",
        "UNEXPECTED ERROR", "ERROR CODE", "FAILED TO CONNECT", "RECONNECT"))
    button = any(re.search(r"\b" + word + r"\b", text) for word in ("RECONNECT", "RETRY", "OK", "LEAVE", "QUIT"))
    return context and button


def slot_enter(lines, slot, width, height):
    """Use the selected slot's column, never another slot's Enter/Unlock/Edit."""
    headers = []
    for line in lines:
        found = re.search(r"\bSLOT\s*0*([1-6])\b", normalize(line.text))
        if found:
            headers.append((int(found[1]), line))
    anchor = next((line for number, line in headers if number == slot), None)
    if anchor is None:
        return None
    right = min([line.x for _, line in headers if line.x > anchor.x and abs(line.y-anchor.y) < height*.08] or [anchor.x + width*.18])
    entries = [line for line in lines if normalize(line.text).startswith("ENTER")
               and anchor.x <= line.cx < right and anchor.y < line.cy < anchor.y+height*.30]
    return entries[0] if len(entries) == 1 else None


class Recovery:
    def __init__(self, runner, launcher=None):
        self.r = runner
        self.launcher = launcher or os.startfile
        self.next_scan = 0.0
        self.next_launch = 0.0
        self.missing_since = None
        self.active = False
        self.started = 0.0
        self.attempts = 0
        self.error_reads = 0
        self.forced = False
        self.stop_at_unfinished = False
        self.holding = False
        self.character_since = None
        self.character_tries = 0
        self.character_target = None

    def launch(self, now):
        if self.holding or self.r.aborted() or now < self.next_launch:
            return
        self.character_since = None
        self.character_tries = 0
        self.character_target = None
        self.attempts += 1
        self.active = True
        self.started = now
        self.next_launch = now + min(300, 90 * self.attempts)
        self.r.status("Reopening Pixel Lineage; waiting for Character Select.")
        try:
            self.launcher(GAME_URI)
        except OSError as exc:
            self.r.status(f"Roblox could not launch: {exc}. Check the Roblox installation.")

    def request_rejoin(self, now):
        """An explicit low-HP escape rejoins even if crash auto-rejoin is off."""
        self.forced = True
        self.stop_at_unfinished = True
        self.attempts = 0
        self.next_launch = 0
        self.next_scan = now
        self.launch(now)

    def missing(self):
        if self.holding:
            return True
        if not (self.forced or self.r.cfg.get("auto_reconnect", True)):
            return False
        now = time.perf_counter()
        if self.missing_since is None:
            self.missing_since = now
        if now-self.missing_since >= 5:
            self.launch(now)
        return True

    def _stop_recovery(self, message):
        self.holding = self.active = True
        self.r.adventure.resume_difficulty = None
        self.r.status(message)
        self.r.note("recovery_stop", message)
        return True

    def _stop_at_unfinished(self):
        return self._stop_recovery("HP protection: character loaded. Macro stopped at UNFINISHED BATTLE.")

    def step(self, rect, frame, battle=False):
        self.missing_since = None
        if self.holding:
            return True
        if self.r.aborted():
            return self.active
        now = time.perf_counter()
        if now < self.next_scan:
            return self.active
        self.next_scan = now + 1.2
        img, ox, oy = crop(frame, self.r.cfg.get("reconnect_area") or DEFAULT_AREAS["reconnect_area"])
        # Full-screen OCR shrinks the title button and confuses SLOT 01/02.
        # Focused OCR preserves the small labels and their client coordinates.
        central = self.r.reader.read(img)
        central_text = " ".join(line.text for line in central)
        normalized = normalize(central_text)
        if "UNFINISHED BATTLE" in normalized:
            return self._stop_at_unfinished()
        if not (self.forced or self.r.cfg.get("auto_reconnect", True)):
            return False
        error = disconnected(central_text)
        self.error_reads = self.error_reads+1 if error else 0
        if error:
            if self.error_reads >= 2:
                self.launch(now)
            return True
        lines = [Line(line.text,line.x+ox,line.y+oy,line.w,line.h) for line in central]
        slots = "YOUR CHARACTERS" in normalized
        if slots:
            self.character_since = None
            self.character_tries = 0
            self.character_target = None
            self.active = True
            slot = max(1, min(6, int(self.r.cfg.get("character_slot", 1))))
            target = slot_enter(lines, slot, rect.w, rect.h)
            if target and not self.r.aborted():
                self.r._focus()
                self.r._click(rect, target.cx, target.cy)
                self.next_scan = now + 2.0
                self.r.status(f"Entering character slot {slot}.")
            else:
                self.r.status(f"Slot {slot}: waiting for a visible Enter button. Locked/empty slots are not selected.")
            return True
        if self.active or not battle:
            title, tx, ty = crop(frame, {"x": .018, "y": .75, "w": .20, "h": .20})
            target = None
            if self.character_target is not None and not battle:
                width, height, cx, cy = self.character_target
                if (width, height) == (rect.w, rect.h):
                    # Reuse the verified button only while its active gold box
                    # remains visible, even if small text briefly fails OCR.
                    for button in find_buttons(title, rect.w, rect.h):
                        b = button.box
                        if button.active and tx+b.x <= cx < tx+b.x+b.w and ty+b.y <= cy < ty+b.y+b.h:
                            target = (cx, cy)
                            break
            if target is None:
                character = next((line for line in self.r.reader.read(title)
                                  if normalize(line.text) == "CHARACTER SELECT"), None)
                if character is not None:
                    target = (tx+character.cx, ty+character.cy)
                    self.character_target = (rect.w, rect.h, *target)
            if self.character_since is not None and (now-self.character_since >= CHARACTER_RETRY_WINDOW
                                                       or self.character_tries >= CHARACTER_RETRY_LIMIT):
                return self._stop_recovery("Character Select did not open within 10 seconds. Macro stopped; F1 retries.")
            if target is not None and not battle:
                if not self.active:
                    self.started = now
                self.active = True
                if self.character_since is None:
                    self.character_since = now
                if not self.r.aborted():
                    self.r._focus()
                    self.r._click(rect, *target)
                    self.character_tries += 1
                self.next_scan = now + CHARACTER_RETRY_SEC
                self.r.status(f"Opening Character Select ({self.character_tries}/{CHARACTER_RETRY_LIMIT}); retrying twice per second.")
                return True
            if self.character_since is not None:
                self.next_scan = now + CHARACTER_RETRY_SEC
                return True
        if self.active and not self.stop_at_unfinished:
            castle, _, _ = crop(frame, {"x": .84, "y": .9, "w": .16, "h": .1})
            if "SET OUT" in normalize(self.r.reader.text(castle)):
                self.r.adventure.running = self.r.adventure.returning = False
                self.r.adventure.reset_lobby()
                self.r.adventure.candidate = None
                self.r.adventure.hits = 0
                self.active = self.forced = False
                self.attempts = 0
                self.next_launch = 0
                return False
        if self.active:
            # SET OUT is behind the unfinished-battle overlay. Never use it to
            # finish HP recovery before that overlay has been checked.
            if self.stop_at_unfinished:
                self.r.status("Character recovery: waiting for UNFINISHED BATTLE; no battle or travel inputs.")
                return True
            self.r.status("Waiting for Roblox to load the character or castle...")
            if now-self.started > 180:
                self.launch(now)
            return True
        return False
